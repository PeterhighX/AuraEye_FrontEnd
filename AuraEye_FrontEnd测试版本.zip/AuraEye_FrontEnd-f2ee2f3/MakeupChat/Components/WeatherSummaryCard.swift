import SwiftUI

struct WeatherSummaryCard: View {
    var aiMessage: String
    var showFirstTimeHint: Bool = false

    var body: some View {
        ZStack(alignment: .top) {
            RoundedRectangle(cornerRadius: 24)
                .fill(Color(red: 1.0, green: 0.93, blue: 0.91).opacity(0.4))
                .shadow(color: Color.black.opacity(0.09), radius: 2, y: 2)
                .frame(height: showFirstTimeHint ? 205 : 161)
                .offset(y: 19)

            HStack(alignment: .bottom) {
                Image("HomeWeatherCloud")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 124, height: 81)

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    HStack {
                        HStack(alignment: .top, spacing: 2) {
                            Text("26")
                                .font(.system(size: 24, weight: .semibold))
                                .foregroundStyle(Color(red: 85 / 255, green: 85 / 255, blue: 85 / 255))
                            VStack(alignment: .leading, spacing: 0) {
                                Text("℃")
                                    .font(.system(size: 10, design: .rounded))
                                Text("多云")
                                    .font(.system(size: 10, design: .rounded))
                            }
                            .foregroundStyle(Color(red: 157 / 255, green: 157 / 255, blue: 157 / 255))
                        }

                        Spacer()

                        Text("福田区")
                            .font(.system(size: 12, weight: .light))
                            .foregroundStyle(Color(red: 102 / 255, green: 102 / 255, blue: 102 / 255))
                            .padding(.horizontal, 6)
                            .frame(height: 18)
                            .background(Color.white.opacity(0.45))
                            .clipShape(Capsule())
                    }

                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.white.opacity(0.45))
                            .frame(height: 9)
                        Capsule()
                            .fill(Color(red: 1.0, green: 139 / 255, blue: 104 / 255))
                            .frame(width: 60, height: 9)
                    }
                    .frame(width: 183)

                    HStack {
                        HStack(spacing: 3) {
                            Image(systemName: "sun.max.fill")
                                .font(.system(size: 12))
                            Text("紫外线指数")
                                .font(.system(size: 12))
                        }
                        Text("19")
                            .font(.system(size: 12))
                        Spacer()
                        Text("弱")
                            .font(.system(size: 12))
                    }
                    .foregroundStyle(Color(red: 102 / 255, green: 102 / 255, blue: 102 / 255))
                    .frame(width: 183)
                }
            }
            .padding(.horizontal, 32)
            .padding(.top, 4)

            HStack(alignment: .top, spacing: 12) {
                Image(showFirstTimeHint ? "FirstTimeAssistant" : "AvatarAI")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 36, height: 36)
                    .clipShape(Circle())

                Text(aiMessage)
                    .font(.system(size: 14, weight: .thin))
                    .foregroundStyle(Color(red: 51 / 255, green: 51 / 255, blue: 51 / 255))
                    .lineSpacing(4)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 7)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white.opacity(0.75))
                    .clipShape(
                        UnevenRoundedRectangle(
                            topLeadingRadius: 0,
                            bottomLeadingRadius: 13,
                            bottomTrailingRadius: 13,
                            topTrailingRadius: 13
                        )
                    )
            }
            .padding(.horizontal, 32)
            .offset(y: 109)
        }
        .frame(height: showFirstTimeHint ? 224 : 180)
        .padding(.horizontal, 16)
    }
}
